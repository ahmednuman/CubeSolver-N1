import cv2
import numpy as np
import PIL
from matplotlib import pyplot as plt

for k in range (100):
    cap = cv2.VideoCapture(0)
    while(True):
        ret, frame = cap.read()
        if(ret):
            cv2.rectangle(frame, (200, 100), (400, 300), (0, 0, 0), 3)
            cv2.rectangle(frame, (200, 100), (267, 167), (0, 0, 0), 1)
            cv2.rectangle(frame, (267, 167), (333, 233), (0, 0, 0), 1)
            cv2.rectangle(frame, (333, 233), (400, 300), (0, 0, 0), 1)
            cv2.rectangle(frame, (200, 100), (267, 167), (0, 0, 0), 1)
            cv2.rectangle(frame, (267, 100), (333, 167), (0, 0, 0), 1)
            cv2.rectangle(frame, (333, 100), (400, 167), (0, 0, 0), 1)
            cv2.rectangle(frame, (200, 167), (267, 233), (0, 0, 0), 1)
            cv2.rectangle(frame, (200, 233), (267, 300), (0, 0, 0), 1)
            cv2.rectangle(frame, (267, 233 ), (333, 300), (0, 0, 0), 1)
            frame = cv2.rotate(frame, cv2.ROTATE_90_COUNTERCLOCKWISE)

            cv2.imshow("output", frame)
            if cv2.waitKey(1) & 0xFF == ord('c'):
                cv2.imwrite('cube.jpg', frame)
                break
        else:
            break
    cv2.destroyAllWindows()
    cap.release()

    img = cv2.imread('cube.jpg')
    height, width, channels = img.shape
    print (height, width, channels)

    x, y, w, h = 100, 240, 200, 200

    img = img[y:y+h, x:x+w]
    img = cv2.resize(img, (300, 300), interpolation = cv2.INTER_AREA)
    cv2.imshow("output", img)
    cv2.imwrite(f"{k}.jpg", img)
    
    cv2.waitKey(0)
    cv2.destroyAllWindows()

