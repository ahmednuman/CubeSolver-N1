import cv2
import numpy as np
import PIL
import os
from matplotlib import pyplot as plt


img = cv2.imread('cube.jpg')
c = 0

x = [285,235,335,270,310,270,310,220,360]
y = [160,135,135,200,200,260,260,175,175]
w = [30,30,30,20,20,20,20,20,20]
h = [20,20,20,30,30,30,30,30,30]

for c in range(9):
    cropped_img = img[y[c]+1:y[c]+h[c], x[c]+1:x[c]+w[c]]
    path = 'C:/Users/Ahmed/Pictures/cells'
    cv2.imwrite(os.path.join(path , f"{c}.jpg"), cropped_img)




