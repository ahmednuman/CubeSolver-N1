import cv2
import numpy as np
import PIL
from matplotlib import pyplot as plt

#for k in range (100):
cap = cv2.VideoCapture(0)
while(True):
    ret, frame = cap.read()
    if(ret):

        cv2.rectangle(frame, (285, 180), (315, 160), (0, 0, 0), 1)
        cv2.rectangle(frame, (235, 155), (265, 135), (0, 0, 0), 1)
        cv2.rectangle(frame, (335, 155), (365, 135), (0, 0, 0), 1)

        cv2.rectangle(frame, (270, 200), (290, 230), (0, 0, 0), 1)
        cv2.rectangle(frame, (310, 200), (330, 230), (0, 0, 0), 1)

        cv2.rectangle(frame, (270, 260), (290, 290), (0, 0, 0), 1)
        cv2.rectangle(frame, (310, 260), (330, 290), (0, 0, 0), 1)

        cv2.rectangle(frame, (220, 175), (240, 205), (0, 0, 0), 1)
        cv2.rectangle(frame, (360, 175), (380, 205), (0, 0, 0), 1)

        cv2.imshow("output", frame)
        if cv2.waitKey(1) & 0xFF == ord('c'):
            cv2.imwrite('cube.jpg', frame)
            break
    else:
        break
cv2.destroyAllWindows()
cap.release()

img = cv2.imread('cube.jpg')
#     height, width, channels = img.shape
#     print (height, width, channels)

#     x, y, w, h = 100, 240, 200, 200

#     img = img[y:y+h, x:x+w]
#     img = cv2.resize(img, (300, 300), interpolation = cv2.INTER_AREA)
#     cv2.imshow("output", img)
#     cv2.imwrite(f"{k}.jpg", img)

cv2.waitKey(0)
cv2.destroyAllWindows()