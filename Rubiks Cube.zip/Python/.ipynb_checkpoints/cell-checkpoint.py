import cv2
import numpy as np
import PIL
import os
from matplotlib import pyplot as plt

import cv2
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image

img = cv2.imread('stitched.jpg')
c = 0
for i in range (30):
    for j in range (30):
        c += 1
        x, y, w, h = (j*100)+40, (i*100)+40, 20, 20
        cropped_img = img[y:y+h, x:x+w]
        path = 'C:/Users/Ahmed/Pictures/cells'
        cv2.imwrite(os.path.join(path , f"{c-1}.jpg"), cropped_img)