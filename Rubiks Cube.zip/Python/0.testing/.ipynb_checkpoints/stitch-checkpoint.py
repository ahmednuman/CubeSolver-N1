import cv2
import numpy as np
import PIL
from matplotlib import pyplot as plt

from PIL import Image

result = Image.new('RGB', (3000, 3000))

for i in range (10):
    for j in range (10):
        im = Image.open(f"{(i*10)+j}.jpg")
        
        result.paste(im, box=(j*300, i*300))
result.save('stitched.jpg')
